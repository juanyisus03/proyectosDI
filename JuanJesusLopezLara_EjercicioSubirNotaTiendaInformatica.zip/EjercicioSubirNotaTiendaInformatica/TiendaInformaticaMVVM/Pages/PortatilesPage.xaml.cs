namespace TiendaInformaticaMVVM.Pages;

public partial class PortatilesPage : ContentPage
{
	public PortatilesPage()
	{
		InitializeComponent();
	}
}