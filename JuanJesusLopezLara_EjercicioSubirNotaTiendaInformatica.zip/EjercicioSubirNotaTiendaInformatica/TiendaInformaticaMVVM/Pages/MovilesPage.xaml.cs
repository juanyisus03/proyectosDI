namespace TiendaInformaticaMVVM.Pages;

public partial class MovilesPage : ContentPage
{
	public MovilesPage()
	{
		InitializeComponent();
	}
}