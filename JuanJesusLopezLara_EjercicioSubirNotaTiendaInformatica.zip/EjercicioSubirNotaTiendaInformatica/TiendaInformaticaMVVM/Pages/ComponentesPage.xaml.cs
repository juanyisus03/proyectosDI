namespace TiendaInformaticaMVVM.Pages;

public partial class ComponentesPage : ContentPage
{
	public ComponentesPage()
	{
		InitializeComponent();
	}
}