namespace TiendaInformaticaMVVM.Pages;

public partial class ChipStore : ContentPage
{
	public ChipStore()
	{
		InitializeComponent();
	}
}