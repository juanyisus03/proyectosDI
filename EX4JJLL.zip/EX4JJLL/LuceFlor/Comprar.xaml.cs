namespace LuceFlor;

public partial class Comprar : ContentPage
{
	public Comprar()
	{
		InitializeComponent();
		
	}
}