namespace LuceFlor;

public partial class Flores : ContentPage
{
	public Flores()
	{
		InitializeComponent();
	}
}